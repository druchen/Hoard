/** Shared fetch, WebP conversion, and native bridge helpers. */

const WEBP_QUALITY = 0.8;

function hoardIsShotdeckPage() {
  const host = location.hostname;
  return host === "shotdeck.com" || host.endsWith(".shotdeck.com");
}

function hoardIsArtStationPage() {
  const host = location.hostname;
  return host === "artstation.com" || host.endsWith(".artstation.com");
}
const HOARD_TOAST_ID = "hoard-save-toast";

function showHoardToast(title, message, isError) {
  let el = document.getElementById(HOARD_TOAST_ID);
  if (!el) {
    el = document.createElement("div");
    el.id = HOARD_TOAST_ID;
    Object.assign(el.style, {
      position: "fixed",
      bottom: "24px",
      right: "24px",
      zIndex: "2147483647",
      maxWidth: "380px",
      padding: "12px 16px",
      borderRadius: "8px",
      fontFamily: "system-ui, sans-serif",
      fontSize: "13px",
      lineHeight: "1.45",
      boxShadow: "0 4px 20px rgba(0,0,0,.35)",
      color: "#fff",
      pointerEvents: "none",
      whiteSpace: "pre-wrap",
    });
    document.documentElement.appendChild(el);
  }

  el.style.background = isError ? "#8b2e2e" : "#2d6a3e";
  el.textContent = "";
  const heading = document.createElement("strong");
  heading.textContent = title;
  el.appendChild(heading);
  el.appendChild(document.createElement("br"));
  el.appendChild(document.createTextNode(message));
  el.style.display = "block";
  clearTimeout(el._hoardTimer);
  el._hoardTimer = setTimeout(() => {
    el.style.display = "none";
  }, isError ? 9000 : 5000);
}

function reportSaveResult(result) {
  if (!result?.ok) {
    showHoardToast(
      "Hoard save failed",
      result?.error || "Unknown error",
      true
    );
  } else {
    let msg = `Saved: ${result.filename || "image"}`;
    if (result.folder) {
      msg += `\n${result.folder}`;
    }
    if (result.note) {
      msg += `\n(${result.note})`;
    }
    showHoardToast("Hoard", msg, false);
  }

  chrome.runtime.sendMessage({ action: "showResult", result }, () => {
    void chrome.runtime.lastError;
  });
}

function convertToWebP(blob, quality = WEBP_QUALITY) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0);
      canvas.toBlob(
        (webp) => {
          if (webp) resolve(webp);
          else reject(new Error("WebP conversion failed"));
        },
        "image/webp",
        quality
      );
    };
    img.onerror = () => reject(new Error("Failed to decode image"));
    img.src = URL.createObjectURL(blob);
  });
}

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result.split(",")[1]);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

function saveViaNativeBridge(payload) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ action: "nativeSave", ...payload }, (result) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      resolve(result);
    });
  });
}

function requestBackgroundSave(payload, timeoutMs = 120000) {
  return new Promise((resolve) => {
    const timeout = setTimeout(() => {
      resolve({
        ok: false,
        error: "Save timed out. Reload the extension and try again.",
      });
    }, timeoutMs);

    chrome.runtime.sendMessage({ action: "hoardSaveRemote", ...payload }, (result) => {
      clearTimeout(timeout);
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      resolve(result || { ok: false, error: "No response from background save." });
    });
  });
}

const IMAGE_URL_EXT = /\.(jpe?g|png|gif|webp|avif)(\?|#|$)/i;

function isImageResponse(contentType, url) {
  const type = (contentType || "").toLowerCase();
  if (type.includes("svg")) {
    return false;
  }
  if (!type || type.includes("octet-stream")) {
    return IMAGE_URL_EXT.test(url || "");
  }
  return type.includes("image");
}

function shouldFetchImageInBackground(url) {
  return /^https?:\/\//i.test(url || "");
}

function base64ToBlob(base64, contentType) {
  const raw = atob(base64);
  const bytes = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) {
    bytes[i] = raw.charCodeAt(i);
  }
  return new Blob([bytes], { type: contentType || "image/jpeg" });
}

async function fetchImageBlobViaBackground(url, referer) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ action: "fetchImage", url, referer }, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (!response?.ok) {
        const detail = response?.url ? `\n${response.url}` : "";
        reject(new Error((response?.error || "Failed to download image") + detail));
        return;
      }
      resolve(base64ToBlob(response.data, response.contentType));
    });
  });
}

async function fetchImageBlobLocal(url, referer) {
  const response = await fetch(url, {
    credentials: "include",
    headers: referer ? { Referer: referer } : {},
  });
  if (!response.ok) {
    throw new Error(`Failed to download image (${response.status})`);
  }
  const contentType = response.headers.get("Content-Type") || "";
  if (!isImageResponse(contentType, url)) {
    throw new Error("URL did not return a supported image");
  }
  return response.blob();
}

async function fetchImageBlob(url, referer) {
  if (shouldFetchImageInBackground(url)) {
    return fetchImageBlobViaBackground(url, referer);
  }
  return fetchImageBlobLocal(url, referer);
}

async function fetchImageBlobCandidates(urls, referer) {
  let lastError = null;
  for (const url of urls) {
    try {
      return await fetchImageBlob(url, referer);
    } catch (err) {
      lastError = err;
    }
  }
  throw lastError || new Error("Failed to download image");
}
